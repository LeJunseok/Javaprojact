//0526 #6
//���ٽ�

package test6;


interface Printable
{
	public void print(String s);
}

public class Test
  {

	public static void main(String[] args)
	{
		Printable p;
		
		// Runnable task1 =() -> {};
		p = (String s) -> {System.out.println(s);};
		p.print("Lambda expr one");
		
		p = (String s) -> {System.out.println(s);};
		p.print("Lambda expr two");

	}

  }
