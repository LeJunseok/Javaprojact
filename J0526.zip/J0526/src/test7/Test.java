//0526 #7
//���ٽ�

package test7;

interface calculate
{
	public void cal (int a, int b);
}
public class Test
{
	public static void main(String[] args)
	{
		
	}
	
}
