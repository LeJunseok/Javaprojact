//0519 #10 Ȧ�� �� ¦���� ��
package test10;

public class Test {

	public static void main(String[] args) {
		// odd number sum
		int odd_sum = 0;
		for (int i=0; i<100; i++)
		{
			if (i % 2 == 1)
				odd_sum += i;
		}
		System.out.println("odd sum = " + odd_sum);
		
		int even_sum = 0;
		for (int i=0; i<100; i++)
		{
			if (i % 2 == 0)
				even_sum += i;
		}
		System.out.println("even sum = " + even_sum);
	}

}
